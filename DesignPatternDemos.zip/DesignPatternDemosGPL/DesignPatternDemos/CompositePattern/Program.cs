﻿/* 
Copyright 2019 By LPGTE
Designpatterndemos is developped with the help of Tutorialpoint Web Site.

this file is part of Designpatterndemos.

Designpatterndemos is free software: you can redistribute it and/or modify
it under the terms of the gnu general public license as published by
the free software foundation, either version 3 of the license, or
(at your option) any later version.

Designpatterndemos is distributed in the hope that it will be useful,
but without any warranty; without even the implied warranty of
merchantability or fitness for a particular purpose.  see the
gnu general public license for more details.

you should have received a copy of the gnu general public license
along with Designpatterndemos. if not, see <https://www.gnu.org/licenses/> /*/

using Structure_CompositePattern.CompositePattern;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositePattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Produit prodOrdianteur = new Produit("Ordinateur", "DF145-UIOF", 1200);
            Produit ProduitClavier = new Produit("Clavier", "MPOL4K-HOIT", 20);
            Produit ProduitSouris = new Produit("Souris", "MLOI-GHTY6", 10);

            prodOrdianteur.add(ProduitClavier);
            prodOrdianteur.add(ProduitSouris);

            //print all employees of the organization
            Console.WriteLine("***** Produit Principale ********** ");
            Console.WriteLine(prodOrdianteur.toString());
            Console.WriteLine("***** Produit Composants ********** ");

            foreach (Produit prod in prodOrdianteur.getSubProducts())
            {
                Console.WriteLine(prod.toString());
            };

            Console.ReadLine();
        }
    }
}
