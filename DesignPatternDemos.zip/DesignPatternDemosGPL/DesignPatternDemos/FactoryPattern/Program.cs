﻿/* 
Copyright 2019 By LPGTE
Designpatterndemos is developped with the help of Tutorialpoint Web Site.

this file is part of Designpatterndemos.

Designpatterndemos is free software: you can redistribute it and/or modify
it under the terms of the gnu general public license as published by
the free software foundation, either version 3 of the license, or
(at your option) any later version.

Designpatterndemos is distributed in the hope that it will be useful,
but without any warranty; without even the implied warranty of
merchantability or fitness for a particular purpose.  see the
gnu general public license for more details.

you should have received a copy of the gnu general public license
along with Designpatterndemos. if not, see <https://www.gnu.org/licenses/> /*/

using Creation_FactoryPattern.FactoryPattern;
using FactoryPattern.FactoryPatternImplementation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            //get personne factory
            PersonneFactory personneFactory =new PersonneFactory ();
            //get an object of Personne Homme
            Personne homme1 = (Homme)personneFactory.getPersonne("HOMME", "Dupond Homme 1");
            homme1.ShowName();

            //get an object of Personne Femme
            Personne femme1 = (Femme)personneFactory.getPersonne("FEMME", "Natia Femme 1");
            femme1.ShowName();

            Console.ReadLine();
        }
    }
}
