﻿/* 
Copyright 2019 By LPGTE
Designpatterndemos is developped with the help of Tutorialpoint Web Site.

this file is part of Designpatterndemos.

Designpatterndemos is free software: you can redistribute it and/or modify
it under the terms of the gnu general public license as published by
the free software foundation, either version 3 of the license, or
(at your option) any later version.

Designpatterndemos is distributed in the hope that it will be useful,
but without any warranty; without even the implied warranty of
merchantability or fitness for a particular purpose.  see the
gnu general public license for more details.

you should have received a copy of the gnu general public license
along with Designpatterndemos. if not, see <https://www.gnu.org/licenses/> /*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Creation_MonteurPattern.MonteurPattern
{
    public class MoteurVehiculeRoulant : Moteur
    {
        public String moteur()
        {
            return "Moteur Véhicule Terrain";
        }
    }
}
